/**
 * @author Hoang Anh
 * @version 1.0
 * @since 1 - 11 -2020
 */
public abstract class Dinh {
	// Thuoc tinh
	double x, y;
	
	// Phuong thuc
	double tinhKhoangCach(Dinh _dinh1, Dinh _dinh2) {
		double ketQua = 0;
		// Tinh khoang cach va gan gia tri cho bien ket qua
		return ketQua;
	}
	
	abstract void nhapToaDoDinh();
	
}
