/**
 * @author Hoang Anh
 * @version 1.0
 * @since 1 - 11 -2020
 */
public class SuViecDaQua extends GhiChu {
	// khai báo thuộc tính
	String nguoiLienQuan;
	String ketQuaSV;
	String danhGia;

	// phuong thuc
	@Override
	void nhapThongTin(String maGhiChu, String tieuDe, String noiDungGhiChu, String thoiGian, String diaDiem,
			boolean daBoLo) {
		super.nhapThongTin(maGhiChu, tieuDe, noiDungGhiChu, thoiGian, diaDiem, daBoLo);
		// nhap ten nguoi lien quan, ket qua su viec, danh gia

	}
	
	@Override
	void inTT() {
		super.inTT();
		// nội dung phương thức
	}
}
