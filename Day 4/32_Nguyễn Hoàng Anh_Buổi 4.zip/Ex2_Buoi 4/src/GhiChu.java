/**
 * @author Hoang Anh
 * @version 1.0
 * @since 1 - 11 -2020
 */
public abstract class GhiChu {
	// khai báo thuộc tính
	String maGhiChu;
	String tieuDe;
	String noiDung;
	String thoiGian;
	String diaDiem;
	boolean boLo;

	// Khai phuong thuc
	void nhapThongTin(String maGhiChu, String tieuDe, String noiDungGhiChu, String thoiGian, String diaDiem,
			boolean daBoLo) {
		// ndpt
	}
	
	void xemNoiDung() {
		// ndpt
	}
	
	void inTT() {
		// ndpt
	}

	
}
