/**
 * @author Hoang Anh
 * @version 1.0
 * @since 1 - 11 -2020
 */
public class QuickNote {
	SuKienSapToi[] dsSKST;
	SuViecDaQua[] dsSVDQ;

	void themGhiChu(SuKienSapToi sKST) {
		// ndpt
	}

	void suaGhiChu(SuKienSapToi sKST) {
		// ndpt
	}

	void xoaGhiChu(String maGhiChu) {

	}

	SuKienSapToi[] timKiemGhiChu(String tieuDe) {
		SuKienSapToi[] kQTK = null;
		// ndpt
		return kQTK;
	}

	SuViecDaQua[] timKiemGhiChu(String ten, String diaDiem) {
		SuViecDaQua[] kQTK = null;
		// ndpt
		return kQTK;
	}

	void xemNDGCTheoMaGC(String maGhiChu) {
		// ndpt
	}

	SuKienSapToi[] lietKeBoLo() {
		SuKienSapToi[] kQTK = null;
		// ndpt
		return kQTK;
	}

	void datBaoThuc(String maGhiChu, int soLan, String thoiGianBT, String amThanh) {
		// ndpt
	}
}
