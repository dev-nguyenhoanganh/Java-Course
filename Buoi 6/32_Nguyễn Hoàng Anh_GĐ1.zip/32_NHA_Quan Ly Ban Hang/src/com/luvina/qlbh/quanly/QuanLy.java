/**
 * @Project 32_NHA_Quan Ly Ban Hang
 * @author Hoang Anh
 * @version 1.0
 * @since 5 thg 11, 2020
 */
package com.luvina.qlbh.quanly;
import com.luvina.qlbh.khachhang.KhachHang;
import com.luvina.qlbh.sanpham.*;


public class QuanLy {
	SanPham[] dSSanPham;
	KhachHang[] dSKhachHang;
	// ----- Khach hang ----- 
	public void themKhachHang(KhachHang _khachHangMoi) {
		// ndpt
	}
	
	public void suaKhachHang(KhachHang _khachHangMoi) {
		// ndpt
	}
	
	public void xoaKhachHang(String _soDienThoai) {
		// ndpt
		// Coi _soDienThoai ung voi ID cua khach hang
	}
	
	
	// ----- Quan Ly San pham -----
	public void themSanPham(Quan _quan) {
		// Them quan moi vao danh sach san pham
	}
	
	public void themSanPham(Ao _ao) {
		// Them ao moi vao danh sach san pham
	}
	
	public void suaSanPham(Quan _quan) {
		// Sua thuoc tinh cua quan
	}
	
	public void suaSanPham(Ao _ao) {
		// Sua Ao
	}
	
	public void xoaSanPham(String _maSanPham) {
		// ndpt
	}
	
	public void hienThiTTSanPham(String _maSanPham) {
		// Su dung ham timSanPhamTheoMa() roi hien thi
		// Hien thi thong tin san pham theo ma
	}
	
	public SanPham timSanPhamTheoMa (String _maSanPham) {
		SanPham _ketQua = null;
		// tim kiem theo _maSanPham 
		return _ketQua;
	}
}
