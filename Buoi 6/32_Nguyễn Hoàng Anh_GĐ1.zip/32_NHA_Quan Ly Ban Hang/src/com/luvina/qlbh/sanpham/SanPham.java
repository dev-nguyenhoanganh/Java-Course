/**
 * @Project 32_NHA_Quan Ly Ban Hang
 * @author Hoang Anh
 * @version 1.0
 * @since 5 thg 11, 2020
 */
package com.luvina.qlbh.sanpham;

public abstract class SanPham {
	protected String thuongHieu;
	protected String size;
	protected String gia;
	protected String thongTinSanPham;
	protected String maSanPham;
	
	public void nhapTT(String thuongHieu, String size, String gia, String thongTinSanPham, String maSanPham,
			String dacDiem) {
		// ndpt
	}
	
	public void hienThiTTSanPham() {
		// ndpt
	}
}
