/**
 * @Project 32_NHA_Quan Ly Ban Hang
 * @author Hoang Anh
 * @version 1.0
 * @since 5 thg 11, 2020
 */
package com.luvina.qlbh.sanpham;

public class Ao extends SanPham {
	private String kieuCoAo;
	
	@Override
	public void nhapTT(String thuongHieu, String size, String gia, String thongTinSanPham, String maSanPham,
			String kieuCoAo) {
		super.nhapTT(thuongHieu, size, gia, thongTinSanPham, maSanPham, kieuCoAo);
		// ndpt
	}
	
	@Override
	public void hienThiTTSanPham() {
		super.hienThiTTSanPham();
		// ndpt
	}

	// ------ Get method -----
	/**
	 * @return the kieuCoAo
	 */
	public String getKieuCoAo() {
		return kieuCoAo;
	}
	
	
	
	
	
}
