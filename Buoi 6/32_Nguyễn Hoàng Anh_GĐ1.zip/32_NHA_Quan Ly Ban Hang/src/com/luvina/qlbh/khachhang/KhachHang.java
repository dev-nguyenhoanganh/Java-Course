/**
 * @Project 32_NHA_Quan Ly Ban Hang
 * @author Hoang Anh
 * @version 1.0
 * @since 5 thg 11, 2020
 */
package com.luvina.qlbh.khachhang;

import com.luvina.qlbh.sanpham.*;

public class KhachHang {
	private String soDienThoai; // Coi SDT la ID khach hang
	private String ten;
	private String diaChi;
	private SanPham[] gioHang;
	
	
	public void nhapThongTin(String _soDienThoai, String _ten, String _diaChi) {
		// Them mot khach hang moi
	}
	
	public void themSanPhamVaoGioHang(String _maSanPham) {
		// Noi dung phuong thuc
	}
	
	public void xemTTSanPham(String _maSanPham) {
		// Noi dung phuong thuc
	}
	
	// ------ Get method -----
	/**
	 * @return the soDienThoai
	 */
	public String getSoDienThoai() {
		return soDienThoai;
	}

	/**
	 * @return the ten
	 */
	public String getTen() {
		return ten;
	}

	/**
	 * @return the diaChi
	 */
	public String getDiaChi() {
		return diaChi;
	}

	/**
	 * @return the gioHang
	 */
	public SanPham[] getGioHang() {
		return gioHang;
	}
}
