/**
 * @Project 32_NHA_Quan Ly Dan Cu
 * @author Hoang Anh
 * @version 1.0
 * @since 5 thg 11, 2020
 */
package com.luvina.qldc.quanly;

import com.luvina.qldc.cudan.CuDan;
import com.luvina.qldc.phuong.*;

public class QuanLy {
	Phuong[] dSPhuong;
	
	// ------ Cac thao tac quan ly phuong ------ 
	public void themPhuong(Phuong _phuongMoi) {
		// Them _phuongMoi vao danh sach phuong
	}
	
	public void suaPhuong(Phuong _phuong) {
		// ndpt
	}
	
	public void xoaPhuong(String _iDPhuong) {
		// Xoa phuong khi biet ID cua phuong do
	}
	
	// ------ Cac thao tac quan ly cu dan ------ 
	public void themCuDan(CuDan _cuDanMoi) {
		// Them cu dan moi vao trong phuong
	}
	
	public void suaCuDan(CuDan _cuDan) {
		// Sua _cuDan thanh cu dan moi	
	}
	
	public void xoaCuDan(String _iDCuDan) {
		// Xoa cu dan khoi phuong
	}
	
	public void capNhatCaNhiem(String _iDPhuong) {
		// Cap nhat so ca nhiem benh trong phuong, quan
	}
	
	public void capNhatCaTuVong(String _iDPhuong) {
		// Cap nhat ca tu vong trong phuong, quan
	}
	
}
