/**
 * @Project 32_NHA_Quan Ly Dan Cu
 * @author Hoang Anh
 * @version 1.0
 * @since 5 thg 11, 2020
 */
package com.luvina.qldc.cudan;

public class CuDan {
	private String iDCuDan;
	private String ten;
	private String tuoi;
	private String diaChi;
	private String tinhTrangSucKhoe;
	private String mucDoTiepXuc;
	private boolean nhiemBenh;
	
	public void nhapTT(String _iDCuDan, String _ten, String _diaChi, String _tinhTrangSucKhoe,
			String _mucDoTiepXuc) {
		// Them moi mot cu dan
	}
	
	public CuDan xetNghiem() {
		CuDan _cuDanXetNghiem = null;
		// Xet Nghiem va tra ve ket qua tinhTrangSucKhoe, nhiemBenh
		return _cuDanXetNghiem;
	}
	
	public CuDan khaiBaoSucKhoe() {
		CuDan _cuDanKhaiBao = null;
		// Cu dan khai bao va tra ve ket qua tinhTrangSucKhoe, mucDoTiepXuc, nhiemBenh
		return _cuDanKhaiBao;
	}

	
	// ----- Get method ----
	/**
	 * @return the iDCuDan
	 */
	public String getiDCuDan() {
		return iDCuDan;
	}

	/**
	 * @return the ten
	 */
	public String getTen() {
		return ten;
	}

	/**
	 * @return the tuoi
	 */
	public String getTuoi() {
		return tuoi;
	}

	/**
	 * @return the diaChi
	 */
	public String getDiaChi() {
		return diaChi;
	}

	/**
	 * @return the tinhTrangSucKhoe
	 */
	public String getTinhTrangSucKhoe() {
		return tinhTrangSucKhoe;
	}

	/**
	 * @return the mucDoTiepXuc
	 */
	public String getMucDoTiepXuc() {
		return mucDoTiepXuc;
	}

	/**
	 * @return the nhiemBenh
	 */
	public boolean isNhiemBenh() {
		return nhiemBenh;
	}
	
	
}
