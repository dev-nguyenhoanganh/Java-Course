/**
 * @Project 32_NHA_Quan Ly Dan Cu
 * @author Hoang Anh
 * @version 1.0
 * @since 5 thg 11, 2020
 */
package com.luvina.qldc.phuong;

import com.luvina.qldc.cudan.CuDan;

public class Phuong {
	private String iDPhuong;
	private String tenPhuong;
	private String thongTinMoTa;
	private CuDan[] dSCuDan;
	private String dSNguoiNhiem;
	private int soCaNhiem;
	private int soCaTuVong;
	
	public void nhapTT(String _iDPhuong, String _tenPhuong, String _thongTinMoTa, CuDan[] _dSCuDan,
			String _dSNguoiNhiem, int _soCaNhiem, int _soCaTuVong) {
		// ndpt
	}
	
	public Phuong xetNghiemCuDan(CuDan[] dsCuDan) {
		Phuong _phuongXetNghiem = null;
		// Thuc hien xet nghiem va tra ve danh sach nguoi nhiem, so ca nhiem
		return _phuongXetNghiem;
	}
	
	// ------ Get method -----
	/**
	 * @return the iDPhuong
	 */
	public String getiDPhuong() {
		return iDPhuong;
	}

	/**
	 * @return the tenPhuong
	 */
	public String getTenPhuong() {
		return tenPhuong;
	}

	/**
	 * @return the thongTinMoTa
	 */
	public String getThongTinMoTa() {
		return thongTinMoTa;
	}

	/**
	 * @return the dSCuDan
	 */
	public CuDan[] getdSCuDan() {
		return dSCuDan;
	}

	/**
	 * @return the dSNguoiNhiem
	 */
	public String getdSNguoiNhiem() {
		return dSNguoiNhiem;
	}

	/**
	 * @return the soCaNhiem
	 */
	public int getSoCaNhiem() {
		return soCaNhiem;
	}

	/**
	 * @return the soCaTuVong
	 */
	public int getSoCaTuVong() {
		return soCaTuVong;
	}
}
