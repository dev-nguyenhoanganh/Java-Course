
public class SoNguyenTo {
	// khai bao thuoc tinh
	int soNguyen ;
	boolean cauTraLoi;
	// khai bao phuong thuc
	// phương thức không trả về
	void nhapSoNguyen(int gtriSoNguyen) {
		// nội dung phương thức
		soNguyen = gtriSoNguyen;
	}
     void kiemTra() {
    	 // kiểm tra soNguyen có phải là số nguyên tố hay không.
    	 // Nếu là số nguyên tố: cauTraLoi = true;
//    	 Nếu không phải là số nguyên tố: cauTraLoi = false;
     }
     
     void inTT() {
    	// in ra màn hình giá trị của cauTraLoi. 
    	 
     }
}
