
public class HinhVuong extends TuGiac{

	@Override
	void tinhDT() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	void tinhCV() {
		super.tinhCV();
		// tinhs chu vi tiep
	}

}
