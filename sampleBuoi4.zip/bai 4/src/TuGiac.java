
public abstract class TuGiac {
	// khai báo thuộc tính
	Dinh[] danhSachCacDinh;
	double doDC;
	double dienTich;
	double chuVu;

	// khai báo phương thức
	// phương thức không trả về
	void nhapToaDoCacDinh(Dinh[] danhSachCacDinh) {

	}
	
	abstract void tinhDT();
	
	void tinhCV() {
		// tinh mot canh
	}
	
	
	

}
