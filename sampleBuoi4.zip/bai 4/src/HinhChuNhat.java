
public class HinhChuNhat {

	// khai báo thuộc tính
	double chuVi;
	double dienTich;
	double doDaiCanh;
	double chieuDai;
	double chieuRong;
	char ketQua;
	
	// khai báo phương thức
	// phương thức không trả về
	void tinhChuVi() {
		// nội dung phương thức
	}
    void tinhDienTich() {
    	// nội dung phương thức
    }
    void tinhDoDaiCanh() {
    	// nội dung phương thức
    }
    void tinhChieuDai() {
    	// nội dung phương thức
    }
    void tinhChieuRong() {
    	// nội dung phương thức
    }
    void inketqua() {
    	// nội dung phương thức
    }
}


