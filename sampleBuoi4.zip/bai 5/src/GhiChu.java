
public class GhiChu {
	// khai báo thuộc tính
	String maGhiChu;
	String tieuDe;
	String noiDung;
	String thoiGian;
	String diaDiem;
	boolean boLo;
	
	void nhapTT(String maGhiChu, String tieuDe, String noiDung, 
			String thoiGian, String diaDiem) {
		// ndpt
	}
	
	void xemNoiDung() {
		// ndpt
	}
	
	void inTT() {
		// ndpt
	}
}
