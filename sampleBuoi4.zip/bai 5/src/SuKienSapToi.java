
public class SuKienSapToi extends GhiChu{
	// khai báo thuộc tính
	String thoiGianBaoThuc;
	int soLanBT;
	boolean xacNhanThamGia;
	String amThanhBT;
	

	// khai báo thuộc tính
	// khai báo phương thức
	// phương thức không trả về
	void nhapTT(String maGhiChu, String tieuDe, String noiDung, String thoiGian, String diaDiem, String thoiGianBaoThuc,
			int soLanBT, boolean xacNhanThamGia, String amThanhBaoThuc) {
		// ndpt
	}

	void xacNhanThamGiaSuKien(boolean xacNhanThamGia) {
		// nội dung phương thức
	}
	
	void inTT() {
		// ndpt
	}
	
	void datBaoThuc(int soLan, String thoiGianBT, String amThanh) {
		// ndpt
	}

}
