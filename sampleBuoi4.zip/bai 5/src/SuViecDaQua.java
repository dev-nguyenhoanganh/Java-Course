
public class SuViecDaQua extends GhiChu{
	// khai báo thuộc tính
	String nguoiLienQuan;
	String ketQuaSV;
	String danhGia;

	// phuong thuc
	void nhapTT(String maGhiChu, String tieuDe, String noiDung, String thoiGian, String diaDiem, String nguoiLienQuan,
			String ketQuaSV, String danhGia) {
		// ndpt
	}
	void inTT() {
		// ndpt
	}

}
