/**
 * @author Hoang Anh
 * @date 28-10-2020
 */

public class GhiChu {
	// Khai bao thuoc tinh
	String maGhiChu;
	String tieuDe;
	String noiDung;
	String thoiGian;
	String diaDiem;
	final int ARRAY_LENGTH = 50;
	// Khai bao phuong thuc
	void taoGhiChu() {
		// Noi dung phuong thuc
	}
	
	void xoaGhiChu() {
		// Noi dung phuong thuc
	}
	
	GhiChu[] timKiem(String _theoThuocTinh) {
		GhiChu danhSachTraVe[] = new GhiChu[ARRAY_LENGTH];
		// Noi dung phuong thuc
		return danhSachTraVe;
	}
	
	GhiChu[] lietKeSuKienDaBoLo() {
		GhiChu danhSachTraVe[] = new GhiChu[ARRAY_LENGTH];
		// Noi dung phuong thuc
		return danhSachTraVe;
	}
	
	void hienThi(String _maGhiChu) {
		// Hien thi noi dung cua ghi chu
	}
}
