/**
 * @author Hoang Anh
 * @date 28-10-2020
 */
public class SuViecDaQua {
	// Khai bao thuoc tinh
	String tenNguoiLienQuan;
	String ketQuaSuViec;
	String danhGia;
	
	// Khai bao phuong thuc
	void nhapKetQua() {
		// Yeu cau nguoi dung nhap ket qua cua "SuViec"
	}
	
	void nhapDanhGia() {
		// Yeu cau nguoi dung nhap danh gia
	}
	
	void nhapTenNguoiLienQuan() {
		// Yeu cau nguoi dung nhap ten nguoi lien quan
	}
}
