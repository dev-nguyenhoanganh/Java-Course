/**
 * @author Hoang Anh
 * @date 28-10-2020
 */
public class SuKienSapToi {
	// Khai bao thuoc tinh
	String thoiGianBaoThuc;
	int soLanBaoThuc;
	String xacNhanThamGia;
	String amBaoThuc;
	
	// Khai bao phuong thuc
	void thongBao() {
		// Dua ra thong bao cho nguoi dung ve su kien sap toi
	}
	
	void yeuCauXacNhan() {
		// Yeu cau nguoi dung xac nhan: "Tham gia" - "Khong tham gia"
	}
	
	void caiDatAmBao() {
		// Yeu cau nguoi dung cai dat "amBao" cho su kien
	}
}
