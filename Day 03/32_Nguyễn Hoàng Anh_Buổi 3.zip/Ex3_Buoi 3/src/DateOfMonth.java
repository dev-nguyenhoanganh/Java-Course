/**
 * @author Hoang Anh
 * @date 28-10-2020
 */
public class DateOfMonth {
	// Khai bao thuoc tinh
	int date;
	int month;
	int year;
	
	// Khai bao phuong thuc
	static void getMonthAndYear() {
		// Nhap gia tri month, year tu ban phim
	}
	
	static int caculate() {
		date = 0;
		// Tinh toan gia tri cua Date
		return date;
	}
	
	static void display() {
		// Hien thi gia tri cua ngay-thang-nam
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DateOfMonth day = new DateOfMonth();
		getMonthAndYear();
		caculate();
		display();
	}
}
