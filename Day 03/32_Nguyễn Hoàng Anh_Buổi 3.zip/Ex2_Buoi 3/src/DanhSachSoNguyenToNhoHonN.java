/**
 * @author Hoang Anh
 * @date 28-10-2020
 */
public class DanhSachSoNguyenToNhoHonN {
	// Khai bao thuoc tinh
	int[] danhSachSoNguyenTo;
	int value_N;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DanhSachSoNguyenToNhoHonN danhSach = new DanhSachSoNguyenToNhoHonN();
		
		getValue_N();
		tinhToan();
		display(danhSach.danhSachSoNguyenTo);

	}
	// Khai bao phuong thuc
	static void getValue_N() {
		// Gan gia tri nhap vao tu ban phim cho value_N
	}
	
	static void tinhToan() {
		// Tinh ra cac gia tri so nguyen to
		// Gan cac gia tri nay vao mang: danhSachSoNguyenTo[];
	}
	
	static void display(int[] _array) {
		// Hien thi ra chuoi so nguyen to nho hon N
	}
	

}
