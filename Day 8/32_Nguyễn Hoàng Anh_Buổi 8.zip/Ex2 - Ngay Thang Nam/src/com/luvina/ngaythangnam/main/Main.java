/**
 * @Project_Name Ex2 - Ngay Thang Nam
 * @author Hoang Anh
 * @date 17 thg 11, 2020
 * @version 1.0
 */
package com.luvina.ngaythangnam.main;

import com.luvina.ngaythangnam.date.Date;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Date dateOfMonth = new Date(2,2021);
		dateOfMonth.displayResult();
	}
}
