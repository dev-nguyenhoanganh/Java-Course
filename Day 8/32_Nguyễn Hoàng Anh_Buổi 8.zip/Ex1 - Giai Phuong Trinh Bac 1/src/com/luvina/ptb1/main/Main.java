/**
 * @Project_Name Ex1 - Giai Phuong Trinh Bac 1
 * @author Hoang Anh
 * @date 16 thg 11, 2020
 * @version 1.0
 */
package com.luvina.ptb1.main;

import com.luvina.ptb1.ptb1.PhuongTrinhBac1;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PhuongTrinhBac1 pT1 = new PhuongTrinhBac1(0, 0);
		pT1.giaiPT();
	}

}
