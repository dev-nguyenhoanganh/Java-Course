/**
 * @Project_Name Ex4 - Triangle
 * @author Hoang Anh
 * @date 17 thg 11, 2020
 * @version 1.0
 */
package com.luvina.triangle.main;

import com.luvina.triangle.triangle.Triangle;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Triangle tamGiac = new Triangle(7, 4, 5);
		tamGiac.displayResult();
	}
}