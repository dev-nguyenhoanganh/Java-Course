/**
 * @Project_Name 32_Ex4_Smart Finder
 * @author Hoang Anh
 * @date 25 thg 11, 2020
 * @version 1.0
 */
package com.luvina.smartfinder.main;

import com.luvina.smartfinder.smartfinder.SmartFinder;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SmartFinder number = new SmartFinder(16);
		number.result();
	}

}
